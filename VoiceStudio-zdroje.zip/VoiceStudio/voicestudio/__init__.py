"""Dolaď-IT — offline speech processing."""

__version__ = "1.0.0"
